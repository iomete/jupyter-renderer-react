@ignore
Feature: Shared context for the V1 vs V2 schema parity features (LKH-1077)

  The V1 baseline is the deprecated `api/v1/schema/...` routes: they always run iom-cluster's
  native code. The domain and admin V1 routes forward to V2 while ARROW_FLIGHT_FOR_DB_EXPLORER
  is on, so the features check those answer exactly what V2 answers rather than use them as a
  baseline. The deprecated routes always use the `default` domain, which can read
  `spark_catalog`, so the objects compared live there: this run's seeded database and its
  employees table. Returns the route prefixes, the seeded names and the helpers below.

  Scenario: seed once per run and return the shared context
    * def testData = karate.callSingle('classpath:iomete/tests/sql/setup/test-data.feature', { domain: domain })
    * def computeName = testData.computeName
    * def catalogName = testData.database.split('.')[0]
    * def namespace = testData.database.split('.')[1]
    # V1 baseline: the deprecated routes, always iom-cluster's native code, `default` domain
    * def v1Native = 'api/v1/schema'
    # the V1 URL customers call: forwards to V2 while the flag is on, so it must answer what V2 does
    * def v1Forwarded = 'api/v1/domains/' + domain + '/schema'
    * def v2 = 'api/v2/domains/' + domain + '/sql/schema'
    * def v2Admin = 'api/v2/admin/sql/schema'
    # V2 caches its listings; this run's objects are new
    * def fresh = { forceRefresh: true }
    * def runQuery = function(statement){ return karate.call('classpath:iomete/helpers/query/run-query-v2.feature', { domain: domain, computeName: computeName, statement: statement }).result }
    # the platform's error body: V1 wraps with an empty errorCode, V2 names it
    * def errorBody = { errorMessage: '#string', errorCode: '#string', status: '#number' }
    # listings compared as sets of `namespace.name`, since V1 and V2 order them differently
    * def tableKeys = function(rows){ return rows.map(t => t.namespace + '.' + t.name + (t.isView ? ' (view)' : '')).sort() }
    # the deprecated V1 routes see the `default` domain's catalogs, this run's domain may have more
    * def inCatalog = function(rows){ return rows.filter(r => r.catalog == catalogName) }
