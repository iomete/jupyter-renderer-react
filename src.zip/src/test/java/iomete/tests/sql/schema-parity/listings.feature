@lock=sql
Feature: SQL schema parity — V1 and V2 list the same namespaces and tables

  A client moving from V1 to V2 must see the same tree: the namespaces of a catalog and of the
  domain, and the tables of a namespace, with and without metadata. The catalog-wide table
  list is left out: it walks every database of the catalog and can time out on a shared target.
  V1 here is the deprecated native routes (see setup/parity.feature). Other features and runs
  create and drop databases on the same target at any time, so the scenario compares a
  database of its own (two tables and a view), created through the shared SQL compute and
  dropped afterwards, rather than whole listings; lists are compared as sets, since V2 sorts
  where V1 does not.

  Skips when ARROW_FLIGHT_FOR_DB_EXPLORER is off: every V2 schema endpoint answers 409 then.

  Background:
    * url baseUrl
    * if (!arrowFlightDbExplorerEnabled) karate.log('ARROW_FLIGHT_FOR_DB_EXPLORER is off, V2 schema routes are not served here, skipping')
    * if (!arrowFlightDbExplorerEnabled) karate.abort()
    # route prefixes, this run's seeded database and table, and the comparison helpers
    * def ctx = karate.call('classpath:iomete/tests/sql/schema-parity/setup/parity.feature', { domain: domain })
    * def v1Native = ctx.v1Native
    * def v2 = ctx.v2
    * def catalogName = ctx.catalogName
    * def fresh = ctx.fresh
    * def runQuery = ctx.runQuery
    * def tableKeys = ctx.tableKeys
    * def inCatalog = ctx.inCatalog

  Scenario: V1 and V2 list the same namespaces and tables

    # ===== Setup: a database of this scenario's own, two tables and a view =====
    * def db = 'karate_parity_list_' + runId
    * def full = catalogName + '.' + db
    # DROP DATABASE ... CASCADE leaves the tables behind in this catalog (setup/ddl-db.feature),
    # so the view and the tables go first
    * configure afterScenario = function(){ runQuery('DROP VIEW IF EXISTS ' + full + '.big_orders'); runQuery('DROP TABLE IF EXISTS ' + full + '.orders'); runQuery('DROP TABLE IF EXISTS ' + full + '.customers'); runQuery('DROP DATABASE IF EXISTS ' + full) }
    * runQuery('CREATE DATABASE IF NOT EXISTS ' + full)
    * runQuery('CREATE TABLE IF NOT EXISTS ' + full + '.orders (id INT, amount DOUBLE)')
    * runQuery('CREATE TABLE IF NOT EXISTS ' + full + '.customers (id INT, name STRING)')
    * runQuery('CREATE OR REPLACE VIEW ' + full + '.big_orders AS SELECT id FROM ' + full + '.orders WHERE amount > 100')
    * def expected = ([db + '.big_orders (view)', db + '.customers', db + '.orders']).sort()
    # the shared schema server can take a few seconds to see objects the compute just created,
    # even with forceRefresh, so the V2 reads below wait for them
    * configure retry = { count: 10, interval: 3000 }

    # ===== 1. Namespace lists: the database is in all three =====
    # the database is listed by the catalog's, the domain's flat and the domain's grouped namespaces

    # V1 (native): list the namespaces of the catalog
    Given path v1Native, 'catalogs', catalogName, 'namespaces'
    When method get
    Then status 200
    And match response.map(n => n.namespace) contains db

    # V2: list the namespaces of the catalog
    Given path v2, 'catalogs', catalogName, 'namespaces'
    And params fresh
    And retry until responseStatus == 200 && response.map(n => n.namespace).includes(db)
    When method get
    Then status 200
    And match response.map(n => n.namespace) contains db

    # V1 (native): list every namespace of the domain
    Given path v1Native, 'namespaces'
    When method get
    Then status 200
    And match inCatalog(response).map(n => n.namespace) contains db

    # V2: list every namespace of the domain
    Given path v2, 'namespaces'
    And params fresh
    And retry until responseStatus == 200 && inCatalog(response).map(n => n.namespace).includes(db)
    When method get
    Then status 200
    And match inCatalog(response).map(n => n.namespace) contains db

    # V1 (native): list namespaces grouped by catalog
    Given path v1Native, 'namespaces', 'v2'
    When method get
    Then status 200
    And match response.find(c => c.catalog == catalogName).namespaces contains db

    # V2: list namespaces grouped by catalog
    Given path v2, 'namespaces', 'v2'
    And params fresh
    And retry until responseStatus == 200 && response.find(c => c.catalog == catalogName).namespaces.includes(db)
    When method get
    Then status 200
    And match response.find(c => c.catalog == catalogName).namespaces contains db

    # ===== 2. Tables of the database: same tables and view on V1 and V2 =====
    # its tables and view, the same on both, with and without metadata

    # V1 (native): list the tables of the test database
    Given path v1Native, 'catalogs', catalogName, 'namespaces', db, 'tables'
    When method get
    Then status 200
    And match tableKeys(response) == expected

    # V2: list the tables of the test database
    Given path v2, 'catalogs', catalogName, 'namespaces', db, 'tables'
    And params fresh
    And retry until responseStatus == 200 && response.length >= expected.length
    When method get
    Then status 200
    And match tableKeys(response) == expected

    # V1 (native): list the tables with metadata of the test database
    Given path v1Native, 'catalogs', catalogName, 'namespaces', db, 'tables'
    And param includeMetadata = true
    When method get
    Then status 200
    * def v1WithMetadata = response.map(t => t.name).sort()

    # V2: list the tables with metadata of the test database
    Given path v2, 'catalogs', catalogName, 'namespaces', db, 'tables'
    And param includeMetadata = true
    When method get
    Then status 200
    And match response.map(t => t.name).sort() == v1WithMetadata
