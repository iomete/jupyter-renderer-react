@lock=api
Feature: Model Gateway connections and provider models, the admin API over the gateway's registry

  A connection ties a provider to a provider key (the credential, stored in the platform's secret
  store) and carries the models callers address. A provider model is an id the gateway lists as
  attachable to that provider's connections; a connection's model has to be one of them. What only
  the real platform can prove is that a connection created over a real provider key resolves that
  secret, and lists and reads back with its models and never the key's value. The admin gate,
  syntax rules, the validation order and the registry's own uniqueness handling are covered by
  iom-ai-services' tests and stay out of here.

  Provider models have no delete endpoint, so the model this feature lists (`karate-model`) has a
  fixed name and stays in the registry like the domain does: no run deletes it, so overlapping
  runs cannot take it from each other, and the list keeps one row however many runs there are.

  The whole feature skips on platforms older than 4.0.2, which predate the Model Gateway (builds
  from main count as newer), and where the AI services are not enabled: `ai-services/version`
  answers 404 then. Where they are enabled, the gateway route has to work, so a 404 on it fails.

  Background:
    * if (!platformAtLeast('4.0.2')) karate.log('platform ' + platformVersion + ' predates the Model Gateway, skipping')
    * if (!platformAtLeast('4.0.2')) karate.abort()
    # leaves a provider model behind, since there is no delete, so it runs only where the install allows that
    * if (!platformChangesAllowed()) karate.abort()

    * url baseUrl

    # the AI services are optional
    * if (!aiServicesEnabled()) karate.log('AI services are not enabled on this target, skipping')
    * if (!aiServicesEnabled()) karate.abort()

    * def connectionsPath = 'llm-gateway/v1/admin/connections'
    * def providerModelsPath = 'llm-gateway/v1/admin/provider-models'
    * def keysPath = 'llm-gateway/v1/admin/provider-keys'
    # connection and model names must be lowercase, which runId already is
    * def connName = 'karate-conn-' + runId
    * def modelName = 'karate-conn-model-' + runId
    # fixed: provider models cannot be deleted, so a per-run name would add a row to the list every run
    * def providerModel = 'karate-model'
    * def keyName = 'karate-conn-key-' + runId
    * def keyValue = 'karate-conn-key-value-' + runId
    * def adminHeaders = { 'X-API-Token': '#(token)', Authorization: '#("Bearer " + token)' }

    # teardown: back to admin first, since the failure that triggers this may have left the
    # scenario acting as another user. The connection goes before its key, models first.
    # Each step is a no-op when its object is gone; any other failure fails the teardown
    * configure afterScenario =
      """
      function() {
        karate.configure('headers', adminHeaders);
        var failures = [];
        var steps = [
          { feature: 'classpath:iomete/helpers/ai/delete-connection.feature', args: { name: connName }, what: 'connection' },
          { feature: 'classpath:iomete/helpers/ai/delete-provider-key.feature', args: { key: keyName }, what: 'provider key' }
        ];
        steps.forEach(function(step) {
          try {
            karate.call(step.feature, step.args);
          } catch (e) {
            karate.log(step.what + ' teardown failed:', e);
            failures.push(step.what + ': ' + e);
          }
        });
        if (failures.length > 0) throw 'teardown failed: ' + failures.join('; ');
      }
      """

    # the AI services are enabled, so the gateway routes have to answer
    Given path connectionsPath
    When method get
    Then status 200
    Given path providerModelsPath
    When method get
    Then status 200

    # delete first: `make test-one` reuses the run id, so a killed attempt leaves its objects behind
    * def clearedConnection = call read('classpath:iomete/helpers/ai/delete-connection.feature') { name: '#(connName)' }
    * def clearedKey = call read('classpath:iomete/helpers/ai/delete-provider-key.feature') { key: '#(keyName)' }

  Scenario: a provider model is listed, then a connection over a real provider key is created with it, read, replaced and removed
    # the credential the connection points at: a real key in the platform's secret store
    Given path keysPath
    And request { key: '#(keyName)', value: '#(keyValue)' }
    When method post
    Then status 201

    # the connection's model has to be in the provider's list: 201, or 409 when an earlier attempt
    # of this run already listed it (there is no delete)
    Given path providerModelsPath
    And request { provider: 'openai', model: '#(providerModel)' }
    When method post
    Then assert responseStatus == 201 || responseStatus == 409

    Given path providerModelsPath
    And param provider = 'openai'
    When method get
    Then status 200
    And match response.items[*].model contains providerModel

    # create: 201, with the pinned secret reference and the embedded model
    Given path connectionsPath
    And request { name: '#(connName)', provider: 'openai', auth_type: 'static_bearer', secret_ref: '#(keyName)', models: [{ name: '#(modelName)', model: '#(providerModel)' }] }
    When method post
    Then status 201
    And match response.name == connName
    And match response.provider == 'openai'
    And match response.auth_type == 'static_bearer'
    And match response.enabled == true
    And match response.secret_ref.key == keyName
    And match response.secret_ref.source.type == 'KUBERNETES'
    And match response.models == '#[1]'
    And match response.models[0] contains { connection: '#(connName)', model: '#(providerModel)', enabled: true }
    # the gateway may qualify a model's name with its connection's, so later calls use the name it returned
    * def createdModelName = response.models[0].name
    And assert !karate.pretty(response).contains(keyValue)

    # listed with a count in place of the rows, and no secret value
    Given path connectionsPath
    When method get
    Then status 200
    * def listed = response.items.filter(c => c.name == connName)
    And match listed == '#[1]'
    And match listed[0].models_count == 1
    And match listed[0] contains { provider: 'openai', enabled: true }
    And assert !karate.pretty(response).contains(keyValue)

    # the detail carries the models
    Given path connectionsPath, connName
    When method get
    Then status 200
    And match response.models[*].name contains createdModelName
    And match response.secret_ref.key == keyName
    And assert !karate.pretty(response).contains(keyValue)

    # replace: a full object; the body of a GET is a valid PUT body
    * def detail = response
    * set detail.enabled = false
    Given path connectionsPath, connName
    And request detail
    When method put
    Then status 200
    And match response.enabled == false
    And match response.models == '#[1]'

    # delete: models first, then the connection
    Given path connectionsPath, connName, 'models', createdModelName
    When method delete
    Then status 204

    Given path connectionsPath, connName
    When method delete
    Then status 204

    Given path connectionsPath
    When method get
    Then status 200
    And match response.items[*].name !contains connName
