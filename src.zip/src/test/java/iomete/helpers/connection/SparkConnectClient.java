package iomete.helpers.connection;

import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

// Runs SQL over Spark Connect, the way an external client connects to a compute. Karate cannot
// speak gRPC itself. Called from features through Java.type.
public final class SparkConnectClient {

    private SparkConnectClient() {}

    // Runs one statement and returns its rows keyed by column name, retrying a few times.
    public static List<Map<String, Object>> query(String url, String token, String sql)
            throws InterruptedException {
        return ClientAttempts.withRetries("spark connect", () -> run(url, token, sql));
    }

    // Returns why one attempt failed, or null when it succeeded.
    public static String failure(String url, String token, String sql) {
        return ClientAttempts.failure(() -> run(url, token, sql));
    }

    private static List<Map<String, Object>> run(String url, String token, String sql) {
        SparkSession session = null;
        try {
            session = SparkSession.builder().remote(url.replace("{access_token}", token)).create();
            List<Map<String, Object>> rows = new ArrayList<>();
            for (Row row : session.sql(sql).collectAsList()) {
                Map<String, Object> values = new LinkedHashMap<>();
                String[] names = row.schema().fieldNames();
                for (int i = 0; i < names.length; i++) {
                    values.put(names[i], row.get(i));
                }
                rows.add(values);
            }
            return rows;
        } catch (Exception e) {
            // Scala rethrows checked exceptions undeclared, so catch them all here
            throw ClientAttempts.redacted(e, token);
        } finally {
            if (session != null) {
                try {
                    session.close();
                } catch (Exception ignored) {
                    // a session that never connected has nothing to release
                }
            }
        }
    }
}
